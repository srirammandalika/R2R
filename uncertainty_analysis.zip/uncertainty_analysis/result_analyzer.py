######################################

# Purpose: Analyze and print class-wise uncertain samples with counts.

######################################


import matplotlib.pyplot as plt
import os
import PIL as Image
import json

reconstructed_images_dir = '/Users/srirammandalika/Downloads/Minor/reconstructed_images/'  # Update the path


def load_annotations(annotation_file='/Users/srirammandalika/Downloads/Minor/annotations.json'):
    """
    Load annotations from a JSON file.
    """
    if not os.path.exists(annotation_file):
        raise FileNotFoundError(f"Annotation file not found: {annotation_file}")

    with open(annotation_file, 'r') as file:
        annotations = json.load(file)

    return annotations


def save_classwise_samples(annotations, output_dir):
    """
    Save 5 samples per class for visual verification.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Group samples by class
    class_samples = {}
    for img_name, label in annotations.items():
        if label not in class_samples:
            class_samples[label] = []
        class_samples[label].append(img_name)

    # Save samples
    for label, samples in class_samples.items():
        class_dir = os.path.join(output_dir, label)
        os.makedirs(class_dir, exist_ok=True)

        for idx, sample in enumerate(samples[:5]):  # Limit to 5 samples
            img = Image.open(os.path.join(reconstructed_images_dir, sample))
            img.save(os.path.join(class_dir, f"{label}_sample_{idx}.png"))


annotations = load_annotations()
save_classwise_samples(annotations, output_dir="/path/to/classwise_samples/")


def plot_uncertain_classes(uncertain_samples):
    """Plot bar chart for uncertain class distribution."""
    classes = list(uncertain_samples.keys())
    counts = list(uncertain_samples.values())
    print("Uncertain Samples:", uncertain_samples)
    print("Total Uncertain Classes:", len(uncertain_samples))

    plt.figure(figsize=(10, 6))
    plt.bar(classes, counts, color='skyblue')
    plt.xlabel("Classes")
    plt.ylabel("Uncertain Sample Count")
    plt.title("Uncertain Samples by Class")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig("/Users/srirammandalika/Downloads/Minor/uncertainty_analysis/uncertain_class_plot.png")
    plt.show()

