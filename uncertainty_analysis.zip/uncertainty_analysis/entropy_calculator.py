# ######################################

# # Purpose: Calculate entropy scores for the reconstructed images to measure uncertainty.

# ######################################

# import os
# import numpy as np
# from PIL import Image
# from scipy.stats import entropy


# def calculate_pixel_entropy(image_path):
#     """
#     Calculate pixel-wise entropy for a given image.
#     """
#     img = Image.open(image_path).convert("L")  # Convert to grayscale
#     img_array = np.array(img)

#     # Normalize pixel values to probabilities
#     pixel_counts = np.bincount(img_array.flatten(), minlength=256)
#     probs = pixel_counts / np.sum(pixel_counts)

#     # Calculate entropy
#     return entropy(probs, base=2)


# def calculate_patch_entropy(image_path, patch_size=8):
#     """
#     Calculate patch-wise entropy for a given image.
#     """
#     img = Image.open(image_path).convert("L")  # Convert to grayscale
#     img_array = np.array(img)

#     H, W = img_array.shape
#     entropy_scores = []

#     for i in range(0, H, patch_size):
#         for j in range(0, W, patch_size):
#             patch = img_array[i:i+patch_size, j:j+patch_size]
#             pixel_counts = np.bincount(patch.flatten(), minlength=256)
#             probs = pixel_counts / np.sum(pixel_counts)
#             entropy_scores.append(entropy(probs, base=2))

#     # Return the mean patch entropy
#     return np.mean(entropy_scores)
