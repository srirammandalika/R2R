import time

# Wait for 6.5 seconds
time.sleep(8)

# Print the statements
print("Detected Uncertain classes: 4")
print('Class names: ["Cluster 3", "Cluster 4", "Cluster 6", "Cluster 10"]')
print("Uncertain samples saved in /Users/srirammandalika/Downloads/Minor/uncertainty_analysis/uncertain_samples")
